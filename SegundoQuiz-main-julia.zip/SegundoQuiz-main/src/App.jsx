import { useState } from 'react';
import questions from './questions.json';
import './App.css';
import Footer from "./components/Footer";

function randomiza(vet) {
  const arr = [...vet];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export default function App() {
  const [start, setStart] = useState(false);

  return (
    <>
      <Footer /> 
      <div className="app-content pt-24"> 
        {!start ? (
          <>
            <h2>Perguntemos</h2>
            <p>Aperte o botão abaixo para começar</p>
            <button className="start-button" onClick={() => setStart(true)}>Começar</button>
          </>
        ) : (
          <Game />
        )}
      </div>
    </>
  );
}

function Game() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [options, setOptions] = useState(questions.map(q => randomiza(q.options)));
  const [result, setResult] = useState(Array(questions.length).fill(""));
  const [history, setHistory] = useState([]);
  const [score, setScore] = useState(0);
  const [emPartida, setEmPartida] = useState(true);

  function verifica(opt) {
    const resposta = [...result];
    if (opt === questions[currentQuestion].options[0]) {
      resposta[currentQuestion] = "Resposta Correta";
      setScore(score + 1);
    } else {
      resposta[currentQuestion] = "Resposta Errada";
    }
    setResult(resposta);
  }

  function reset() {
    const attempt = { answers: [...result], score: score };
    setHistory([...history, attempt]);

    setCurrentQuestion(0);
    setResult(Array(questions.length).fill(""));
    setOptions(questions.map(q => randomiza(q.options)));
    setEmPartida(false);
    setScore(0);
  }

  if (emPartida) {
    return (
      <fieldset className="quiz-fieldset">
        <p>{currentQuestion + 1} - {questions[currentQuestion].question}</p>
        <div className="options-container">
          {options[currentQuestion].map((option) => (
            <button
              key={option}
              className="option-button"
              onClick={() => verifica(option)}
              disabled={result[currentQuestion] !== ""}
            >
              {option}
            </button>
          ))}
        </div>

        <p className="result-text">{result[currentQuestion]}</p>

        <div className="navigation-buttons">
          <button onClick={() => setCurrentQuestion(currentQuestion - 1)} disabled={currentQuestion === 0}>Anterior</button>
          <button onClick={() => setCurrentQuestion(currentQuestion + 1)} disabled={currentQuestion === questions.length - 1}>Próxima</button>
        </div>

        <div className="jump-buttons">
          {questions.map((_, index) => (
            <button key={index} onClick={() => setCurrentQuestion(index)}>
              {index + 1}
            </button>
          ))}
        </div>

        <button className="finish-button" onClick={() => reset()}>Finalizar Tentativa</button>

        <p>Acertos: {score} / {questions.length}</p>
      </fieldset>
    );
  }

return (
  <div className="resultados-container">
    <h2>Resultados</h2>
    <ul className="resultados-list">
      {history.map((attempt, index) => (
        <li key={index}>
          Tentativa {index + 1}: [
          {attempt.answers.map((resp, i) => {
            let classe = resp === "Resposta Correta" ? "C" : resp === "" ? "-" : "E";
            return (
              <span key={i} className={classe}>
                {resp === "Resposta Correta" ? "C" : resp === "" ? "-" : "E"}
                {i < attempt.answers.length - 1 ? ", " : ""}
              </span>
            );
          })}
          ]; Acertos: {attempt.score}
        </li>
      ))}
    </ul>
    <button className="start-button" onClick={() => setEmPartida(true)}>
      Jogar novamente
    </button>
  </div>
);

}
