import React from "react";

export default function Footer() {
  return (
    <>
      <aside className="sidebar-left">
        <a
          href="https://www.ufjf.br"
          target="_blank"
          rel="noopener noreferrer"
          className="logo-link"
        >
          <img
            src="src/imagens/UFJF.png"
            alt="Logo UFJF"
            className="logo-sidebar"
          />
        </a>

        <nav className="menu-icons">

        <a
            href="/"
            className="menu-item"
          >
            <img src="src/imagens/home.png" alt="Home" className="icon" />
            <span className="label">Página Inicial</span>
          </a>

          <a
            href="https://instagram.com/ajuliarodri"
            target="_blank"
            rel="noopener noreferrer"
            className="menu-item"
          >
            <img src="src/imagens/insta.png" alt="Instagram" className="icon" />
            <span className="label">Instagram</span>
          </a>
              <a
            href="https://instagram.com/vtr.brandao"
            target="_blank"
            rel="noopener noreferrer"
            className="menu-item"
          >
            <img src="src/imagens/insta.png" alt="Instagram" className="icon" />
            <span className="label">Instagram</span>
          </a>

          {/* GitHub */}
          <a
            href="https://github.com/JuliaaRodrigues"
            target="_blank"
            rel="noopener noreferrer"
            className="menu-item"
          >
            <img src="src/imagens/github-icon.png" alt="GitHub" className="icon" />
            <span className="label">GitHub</span>
          </a>
                    <a
            href="https://github.com/V-Albino"
            target="_blank"
            rel="noopener noreferrer"
            className="menu-item"
          >
            <img src="src/imagens/github-icon.png" alt="GitHub" className="icon" />
            <span className="label">GitHub</span>
          </a>
        </nav>
      </aside>

      <div className="game-footer">
        <h3>
          Projeto Quiz © {new Date().getFullYear()} – Por Julia Rodrigues e Victor Brandão – UFJF
        </h3>
      </div>
    </>
  );
}
